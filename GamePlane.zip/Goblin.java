public class Goblin extends Enemy {
    public Goblin() {
        super("Гоблин", 50, 10, 20);
    }
}
