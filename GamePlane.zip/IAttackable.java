public interface IAttackable {
    void takeDamage(int damage);
    int getHp();
    String getName();
}
