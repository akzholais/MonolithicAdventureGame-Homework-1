public class Dragon extends Enemy {
    public Dragon() {
        super("Дракон", 150, 15, 30);
    }
}
